using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelEnd : MonoBehaviour
{
    public GameObject confetti;
    private AudioSource audioSource;
    public AudioClip winningSound;
    private bool levelEnded = false;
    private void Start()
    {

    }
    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("Player")  && !levelEnded)
        {
            audioSource = other.gameObject.GetComponent<AudioSource>();
            audioSource.Stop();
            audioSource.clip = winningSound;
            audioSource.Play();
            levelEnded = true;
            StartCoroutine(EndLevel());
        }
    }
    IEnumerator EndLevel()
    {
        // Activate confetti
        confetti.SetActive(true);
        GameObject.FindGameObjectWithTag("obs").GetComponent<ObsMovement>().stopGame = true;
        // Make the ball jump
        Rigidbody2D rb = GameObject.FindGameObjectWithTag("Player").GetComponent<Rigidbody2D>();
        rb.AddForce(new Vector2(0, 500f));

        // Wait for some time
        yield return new WaitForSeconds(3f);

        // Load next level or end game
        // ...
    }
}


