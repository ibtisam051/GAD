using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform player;  // the player's transform

    public float smoothTime = 0.3f;  // the time it takes for the camera to catch up to the player
    public Vector3 offset = new Vector3(0, 0, -10);  // the offset between the camera and the player

    private Vector3 velocity = Vector3.zero;  // the velocity of the camera

    void FixedUpdate()
    {
        // the target position of the camera
        Vector3 targetPosition = player.TransformPoint(offset);

        // smoothly move the camera to the target position
        transform.position = Vector3.SmoothDamp(transform.position, targetPosition, ref velocity, smoothTime);
    }
}
