using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OnGroundCollision : MonoBehaviour
{
    private bool check = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (check == false)
        {
            if (collision.gameObject.CompareTag("Player"))
            {
                print("gameover");
            }
            if (collision.gameObject.tag == "obs" && collision.gameObject.GetComponent<ObsMovement>().isPlaced == false)
            {
                check=true;
                // Stick the floating element to the path
                collision.gameObject.transform.position = transform.position;
                collision.gameObject.GetComponent<ObsMovement>().isPlaced = true;
                collision.gameObject.GetComponent<DragandDrop>().dragStop = true;
                collision.gameObject.GetComponent<Rigidbody2D>().isKinematic = true;
                GameObject.FindGameObjectWithTag("Respawn").GetComponent<SpawnManager>().RespawnElement(collision.gameObject);
            }
        }
    }
}
