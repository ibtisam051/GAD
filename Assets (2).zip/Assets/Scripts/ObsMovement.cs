using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObsMovement : MonoBehaviour
{
    public bool isPlaced = false;
    public float followSpeed = 4f; // the speed at which the element follows the player
    private Transform playerTransform;
    Rigidbody2D rb;
    public bool stopGame = false;
    // Start is called before the first frame update
    void Start()
    {
        playerTransform = GameObject.FindGameObjectWithTag("Player").transform;
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        if (stopGame == false)
        {
            if (isPlaced == false)
            {
                rb.velocity = new Vector2(followSpeed, rb.velocity.y);
                // Vector2 targetPosition = new Vector2(playerTransform.position.x+45f, playerTransform.position.y + 6f);
                // transform.position = Vector2.MoveTowards(transform.position, targetPosition, followSpeed * Time.deltaTime);
            }
            else
            {
                Vector2 velocity = gameObject.GetComponent<Rigidbody2D>().velocity;

                // Set X component to zero
                velocity.x = 0f;
                velocity.y = 0f;
                gameObject.GetComponent<Rigidbody2D>().velocity = velocity;
                gameObject.GetComponent<Rigidbody2D>().freezeRotation = true;
            }
        }
        else
        {
            Vector2 velocity = gameObject.GetComponent<Rigidbody2D>().velocity;
            velocity.x = 0f;
            velocity.y = 0f;
            gameObject.GetComponent<Rigidbody2D>().velocity = velocity;
            gameObject.GetComponent<Rigidbody2D>().freezeRotation = true;
        }
    }
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            collision.gameObject.GetComponent<Rigidbody2D>().AddForce(transform.up * 1f);
        }
    }
}
