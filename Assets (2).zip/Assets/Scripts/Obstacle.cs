using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Obstacle : MonoBehaviour
{
    public float speed = 5f; // The speed at which the obstacle moves

    // Update is called once per frame
    void Update()
    {
        // Move the obstacle in the left direction
        transform.Translate(-speed * Time.deltaTime, 0, 0);
    }
}

