using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameOver : MonoBehaviour
{
    public TextMeshProUGUI gameOverText;
    private AudioSource audioSource;
    public AudioClip losingSound;
    private void Start()
    {
        audioSource = GetComponent<AudioSource>();
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Obstacle"))
        {
            Destroy(collision.gameObject);
            GameOverFunction();
        }
    }
    public void GameOverFunction() 
    {
        audioSource.Stop();
        audioSource.clip = losingSound;
        audioSource.Play();
        gameOverText.gameObject.SetActive(true);
        GameObject.FindGameObjectWithTag("obs").GetComponent<ObsMovement>().stopGame = true;
    }
}



