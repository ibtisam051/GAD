using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class ElementRespawm : MonoBehaviour
{
    public GameObject[] elementPrefabs;
    public Tilemap tilemap;
    public Vector3 elementOffset;

    private GameObject currentElement;

    void Start()
    {
        SpawnNewElement();
    }

    void Update()
    {
        if (Input.GetMouseButtonUp(0))
        {
            Vector3 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Vector3Int cellPosition = tilemap.WorldToCell(mousePosition);
            Vector3 elementPosition = tilemap.GetCellCenterWorld(cellPosition) + elementOffset;

            if (tilemap.HasTile(cellPosition) && currentElement != null)
            {
                currentElement.transform.position = elementPosition;
                currentElement = null;
                SpawnNewElement();
            }
        }
    }

    void SpawnNewElement()
    {
        int randomIndex = Random.Range(0, elementPrefabs.Length);
        GameObject element = Instantiate(elementPrefabs[randomIndex], transform.position, Quaternion.identity);
        currentElement = element;
    }
}
