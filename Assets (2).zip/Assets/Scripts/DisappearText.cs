using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class DisappearText : MonoBehaviour
{
    public GameObject objectToDisappear;
    void Start()
    {
        StartCoroutine(Disappear());
    }
    IEnumerator Disappear()
    {
        yield return new WaitForSeconds(3);
        objectToDisappear.SetActive(false);
    }
}
