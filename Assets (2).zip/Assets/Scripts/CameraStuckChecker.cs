using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

public class CinemachineController : MonoBehaviour
{
    public float gameOverTime = 1f;
    private float stationaryTime = 0f;
    private Vector3 previousCameraPosition;
    public GameObject player;

    private void Start()
    {
        previousCameraPosition = transform.position;
    }

    private void Update()
    {
        if (transform.position == previousCameraPosition)
        {
            stationaryTime +=Time.deltaTime;
        }
        else
        {
            stationaryTime = 0f;
        }
        previousCameraPosition = transform.position;

        if (stationaryTime > gameOverTime)
        {
            // Trigger game over event
            player.GetComponent<GameOver>().GameOverFunction();

        }
    }
}
