using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class SpawnManager : MonoBehaviour
{
    public GameObject[] elementPrefabs;
    public Vector3 spawnOffset = new Vector3(0f, 2f, 0f);
    private int n = 0;
    Rigidbody2D rb;
    public float followSpeed = 4f;
    // Start is called before the first frame update
    void Start()
    {
        // Spawn the initial elements
        for (int i = 0; i < elementPrefabs.Length; i++)
        {
            n = i;
            SpawnElement();
        }
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        rb.velocity = new Vector2(followSpeed, rb.velocity.y);
    }

    public void SpawnElement()
    {
        // Spawn a new element at a random position above the player
        Vector3 spawnPosition = transform.position + spawnOffset + Random.insideUnitSphere * 2f;
        Instantiate(elementPrefabs[n], spawnPosition, Quaternion.identity);
    }
    public void RespawnElement(GameObject element)
    {
        print(element.name);
        int index = -1;
        for (int i = 0; i < elementPrefabs.Length; i++)
        {
            if ((elementPrefabs[i].name+"(Clone)") == element.name)
            {
                index = i;
                break;
            }
        }

        if (index == -1)
        {
            Debug.LogError("Element not found in prefab array!");
            return;
        }
        n = index;
        SpawnElement();
    }
}