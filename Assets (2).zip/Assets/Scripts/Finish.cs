using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Finish : MonoBehaviour
{

    private bool hasFinished=false;
    private void OnCollisionEnter2D(Collision2D other){
        Debug.Log("HELLO");
        if (other.gameObject.CompareTag("Player") && !hasFinished)
        {
            Invoke("CompleteLevel",2f);
            hasFinished=true;
            Debug.Log("hello");
        }
    }
    private void CompleteLevel(){
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex+1);
    }
}
