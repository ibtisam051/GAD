using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallMovenment : MonoBehaviour
{
    public float speed = 5f; // The speed at which the ball moves
    private Rigidbody2D rb; // The Rigidbody2D component attached to the ball
    // Start is called before the first frame update
    void Start()
    {
        // Get the Rigidbody2D component attached to the ball
        rb = GetComponent<Rigidbody2D>();
    }
    // Update is called once per frame
    void Update()
    {
        // Move the ball to the right
        rb.velocity = new Vector2(speed, rb.velocity.y);
    }
}

