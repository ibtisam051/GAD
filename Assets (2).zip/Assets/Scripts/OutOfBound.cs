using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OutOfBound : MonoBehaviour
{
    public GameObject virCamera;
    public float distance;
    public bool check = false;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (check == false)
        {
            if (gameObject.transform.position.x != virCamera.transform.position.x + distance)
            {
                Vector3 vector = (Vector3)gameObject.transform.position;
                vector.x = virCamera.transform.position.x + distance;
                gameObject.transform.position = vector;
            }
        }
        else
        {
            if (gameObject.transform.position.x != virCamera.transform.position.x - distance)
            {
                Vector3 vector = (Vector3)gameObject.transform.position;
                vector.x = virCamera.transform.position.x - distance;
                gameObject.transform.position = vector;
            }
        }

    }
    private void OnCollision2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("obs"))
        {
            collision.gameObject.transform.position = gameObject.transform.position;
        }
    }
}
