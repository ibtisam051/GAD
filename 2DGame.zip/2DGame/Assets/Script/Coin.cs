using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coin : MonoBehaviour
{
    public float rotationSpeed = 100f;

    void Update()
    {
        // Rotate the coin around the Y axis
        transform.Rotate(0f, rotationSpeed * Time.deltaTime, 0f);
    }
}
