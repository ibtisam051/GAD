using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class Collectable : MonoBehaviour
{
    private int coin=0;
    private int life=3;
    public TextMeshProUGUI ScoreText, LifeText, timerText,GameOverText;
    int seconds = 0;
    void Start()
    {
        StartCoroutine(Timer());
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("coin"))
        {
            Debug.Log("hello");
            coin++;
            ScoreText.text = "Score:" + coin;
            Destroy(collision.gameObject);
        }
        if (collision.gameObject.CompareTag("Enemy")){
            Debug.Log("enemy");
            life--;
            LifeText.text="Life Left:"+life;
            if(life==0){
                StopAllCoroutines();
                GameOverText.gameObject.SetActive(true);

            }

        }
    }
    IEnumerator Timer()
    {
        while (life>0)
        {
            yield return new WaitForSeconds(1);
            seconds++;
            timerText.text = "Timer: " + seconds;
        }
    }
}
