using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public float moveSpeed = 5f;  // The speed at which the enemy moves
    public float moveRange = 5f;  // The maximum distance the enemy can move from its starting position
    public Vector2 moveDirection = Vector2.right;  // The direction in which the enemy should move

    private float moveDistance;  // The distance the enemy has moved from its starting position
    private Vector2 startingPosition;  // The enemy's starting position

    void Start()
    {
        // Store the starting position of the enemy
        startingPosition = transform.position;
    }

    void Update()
    {
        // Move the enemy in the specified direction at the specified speed
        transform.Translate(moveDirection * moveSpeed * Time.deltaTime);

        // Update the distance the enemy has moved from its starting position
        moveDistance = Vector2.Distance(startingPosition, transform.position);

        // Check if the enemy has moved beyond the specified range
        if (moveDistance > moveRange)
        {
            // Change the direction of movement to the opposite direction
            moveDirection *= -1;
        }
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        // Check if the enemy has collided with the player
        if (other.gameObject.CompareTag("Player"))
        {
            // Destroy the enemy game object
            Destroy(gameObject);
        }
    }
}
