using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float jumpForce = 5f;
    public float speed = 10.0f;
    float dirX;
    Rigidbody2D rb;
    BoxCollider2D myCollider;
    Animator anim;
    [SerializeField] private LayerMask  jumpableGround;
    private enum MovementState{idle,running,jumping,falling}

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        myCollider = GetComponent<BoxCollider2D>();
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        dirX=Input.GetAxisRaw("Horizontal");
        rb.velocity=new Vector2(dirX*speed,rb.velocity.y);
        if (Input.GetKeyDown(KeyCode.Space)&& isGrounded())
        {
            rb.AddForce(new Vector2(0f, jumpForce), ForceMode2D.Impulse); // Make the player jump
        }
        UpdateAnimation();
    }
    private void UpdateAnimation()
    {
        MovementState state;       
        if(dirX>0f)
        {
            state = MovementState.running;
            transform.localScale = new Vector3(1, 1, 1);
        }
        else if(dirX<0f)
        {
            state=MovementState.running;
            transform.localScale = new Vector3(-1, 1, 1);
        }
        else
        {
            state=MovementState.idle;
        }

        if(rb.velocity.y > .1f)
        {
            state=MovementState.jumping;
        }
        else if(rb.velocity.y< -.1f)
        {
            state=MovementState.falling;
        }
        anim.SetInteger("state",(int)state);
    }
    private bool isGrounded()
    {
        return Physics2D.BoxCast(myCollider.bounds.center,myCollider.bounds.size,0f,Vector2.down,.1f,jumpableGround);
    }
}
